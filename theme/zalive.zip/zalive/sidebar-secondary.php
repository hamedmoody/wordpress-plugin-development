<?php
/**
 * footer widget template
 */
 global $zAlive_options;
?>
  <?php if(is_active_sidebar('sidebar-secondary')) : ?>
    <div id="sidebar-secondary" class="container">
      <div class="row">
          <?php dynamic_sidebar('sidebar-secondary'); ?>
      </div>
    </div>
  <?php endif; ?>
    
    
    
    
    
    
    
    
    