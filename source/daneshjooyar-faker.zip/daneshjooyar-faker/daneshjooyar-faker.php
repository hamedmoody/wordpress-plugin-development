<?php
/**
 * Plugin Name: Daneshjooyar Faker
 */

 defined('ABSPATH') || exit;

 register_activation_hook( __FILE__, 'daneshjooyar_faker_run' );
 function daneshjooyar_faker_run(){

    $added = get_option( 'daneshjooyar_faker_run', 'no' );
    
    if( $added == 'no' ){

        include('vendor/autoload.php');

        $faker = Faker\Factory::create( 'fa_IR' );
        
        for( $i = 0; $i < 1000; $i++ ){

            $first_name = $faker->firstName();
            $last_name  = $faker->lastName();

            $user_data = [
                'user_login'        => $faker->userName(),
                'user_email'        => $faker->email(),
                'first_name'        => $first_name,
                'last_name'         => $last_name,
                'user_pass'         => wp_generate_password(),
                'display_name'      => $first_name . ' ' . $last_name,
                'user_registered'   => $faker->date('Y-m-d H:i:s'),

            ];

            $meta = [
                'rate'  => rand( 5, 99 ),
            ];

            if( ! rand( 0, 4 ) ){
                $meta['phone']  = $faker->phoneNumber();
            }

            if( ! rand( 0, 4 ) ){
                $meta['country']  = $faker->country();
                $meta['city']  = $faker->city();
                $meta['address']  = $faker->address();
            }

            $user_data['meta_input'] = $meta;

            if( ! rand( 0, 100 ) ){
                $user_data['role'] = 'author';
            }

            wp_insert_user( $user_data );

        }

        update_option( 'daneshjooyar_faker_run', 'yes' );

    }

 }